REGISTER_ENDPOINT = "https://riwt5hd79f.execute-api.us-east-1.amazonaws.com/default/register_user"

LOGIN_ENDPOINT = "https://v2apssx6fb.execute-api.us-east-1.amazonaws.com/default/login_user"


LIST_PRODUCT_ENDPOINT = "https://6owwy9eo22.execute-api.us-east-1.amazonaws.com/default/listt_product"

LIST_GUEST_CART_ENDPOINT = "https://wxbh5t09za.execute-api.us-east-1.amazonaws.com/default/list_cart_guest"

ADD_TO_GUEST_CART_ENDPOINT = "https://gmzungq13g.execute-api.us-east-1.amazonaws.com/default/add_to_cart_guest"
